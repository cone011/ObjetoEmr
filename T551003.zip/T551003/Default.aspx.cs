﻿using DevExpress.Web.ASPxEditors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        string Name = "TestControl";
        DevExpress.Web.ASPxGridLookup.ASPxGridLookup AControl = new DevExpress.Web.ASPxGridLookup.ASPxGridLookup();
        AControl.ID = Name;
        
        AControl.ClientInstanceName = Name;
        AControl.Width = Unit.Pixel(300);
        EditButton button = new DropDownButton();
        AControl.DropDownButton.Visible = false;
        AControl.Buttons.Add(button);
        AControl.ClientSideEvents.DropDown = "function(s,e) { console.log('Drop Down'); }";
        AControl.ClientSideEvents.ButtonClick = "function(s,e) { console.log('Button Click'); }";        

        AControl.GridView.DataSource = SqlDataSource1;
        AControl.GridView.DataBind();
        form1.Controls.Add(AControl);
    }
}